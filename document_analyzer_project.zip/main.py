import os
import io
import PyPDF2
from fastapi import FastAPI, UploadFile, File, Form, Request
from fastapi.responses import StreamingResponse, HTMLResponse
from fastapi.templating import Jinja2Templates
from openai import AsyncOpenAI
from dotenv import load_dotenv

# Load environment variables securely
load_dotenv()
client = AsyncOpenAI(api_key=os.getenv("OPENAI_API_KEY"))

app = FastAPI()
templates = Jinja2Templates(directory="templates")

@app.get("/", response_class=HTMLResponse)
async def get_home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.post("/analyze")
async def analyze(
    text_input: str = Form(""),
    file_input: UploadFile = File(None),
    analysis_type: str = Form("summarize")
):
    document_text = text_input

    # Extract text if a PDF is uploaded
    if file_input and file_input.filename:
        content = await file_input.read()
        pdf_reader = PyPDF2.PdfReader(io.BytesIO(content))
        extracted_text = ""
        for page in pdf_reader.pages:
            text = page.extract_text()
            if text:
                extracted_text += text
        document_text = extracted_text

    if not document_text.strip():
        return {"error": "No text or file provided."}

    # Generator to stream tokens from OpenAI
    async def stream_generator():
        prompt = f"Please {analysis_type} the following document. Format the output cleanly:\n\n{document_text[:15000]}" 
        
        stream = await client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are an expert document analyst. Provide clear, structured, and highly readable output."},
                {"role": "user", "content": prompt}
            ],
            stream=True,
        )
        async for chunk in stream:
            if chunk.choices[0].delta.content is not None:
                yield chunk.choices[0].delta.content

    return StreamingResponse(stream_generator(), media_type="text/plain")